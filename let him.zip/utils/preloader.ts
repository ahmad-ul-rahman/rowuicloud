
import { routeFactories } from './routeImports';
import { api } from './dataService';

type ComponentKey = keyof typeof routeFactories;

const getComponentKey = (path: string): ComponentKey | null => {
  if (path === '/') return 'HomePage';
  if (path.startsWith('/blog/')) return 'SinglePostPage';
  // Categories
  if (['/tech', '/design', '/tools', '/guides'].some(p => path === p || path.startsWith(p + '/'))) return 'CategoryPage';
  if (path.startsWith('/category/')) return 'CategoryPage';
  if (path === '/categories') return 'CategoriesPage';
  // Other
  if (path.startsWith('/posts')) return 'AllPostsPage';
  if (path === '/about') return 'AboutPage';
  if (path === '/contact') return 'ContactPage';
  if (path === '/privacy') return 'PrivacyPolicyPage';
  if (path === '/terms') return 'TermsPage';
  return null;
};

export const prefetchRoute = (path: string) => {
  // 1. Preload Component Chunk
  const componentKey = getComponentKey(path);
  if (componentKey) {
    routeFactories[componentKey]();
  }

  // 2. Preload Data
  // Blog Details
  if (path.startsWith('/blog/')) {
    const slug = path.split('/blog/')[1];
    if (slug) api.getPostBySlug(slug);
  } 
  // Main Categories
  else if (['/tech', '/design', '/tools', '/guides'].some(p => path === p)) {
    const category = path.substring(1).charAt(0).toUpperCase() + path.substring(2);
    api.getPostsByCategory(category);
  } 
  // All Posts
  else if (path === '/posts') {
    api.getAllPosts('All');
  }
};
