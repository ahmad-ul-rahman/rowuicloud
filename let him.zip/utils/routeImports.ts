
export const routeFactories = {
  HomePage: () => import('../pages/HomePage'),
  CategoryPage: () => import('../pages/CategoryPage'),
  CategoriesPage: () => import('../pages/CategoriesPage'),
  SinglePostPage: () => import('../pages/SinglePostPage'),
  AllPostsPage: () => import('../pages/AllPostsPage'),
  AboutPage: () => import('../pages/AboutPage'),
  ContactPage: () => import('../pages/ContactPage'),
  PrivacyPolicyPage: () => import('../pages/PrivacyPolicyPage'),
  TermsPage: () => import('../pages/TermsPage'),
  AdminDashboard: () => import('../pages/admin/AdminDashboard'),
  AdminLogin: () => import('../pages/admin/AdminLogin'),
};
