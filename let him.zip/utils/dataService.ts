
import { supabase } from '../supabaseClient';
import { BlogPost, Deal, Author } from '../types';

const CACHE_DURATION = 15 * 60 * 1000; // 15 minutes

interface CacheItem<T> {
  data: T;
  timestamp: number;
}

const getFromCache = <T>(key: string): T | null => {
  const itemStr = localStorage.getItem(key);
  if (!itemStr) return null;

  try {
    const item: CacheItem<T> = JSON.parse(itemStr);
    const now = Date.now();
    if (now - item.timestamp > CACHE_DURATION) {
      localStorage.removeItem(key);
      return null;
    }
    return item.data;
  } catch (e) {
    localStorage.removeItem(key);
    return null;
  }
};

const setToCache = <T>(key: string, data: T) => {
  const item: CacheItem<T> = {
    data,
    timestamp: Date.now(),
  };
  try {
    localStorage.setItem(key, JSON.stringify(item));
  } catch (e) {
    console.warn('Cache write failed', e);
  }
};

export const api = {
  getLatestPosts: async (limit: number = 7): Promise<BlogPost[]> => {
    const cacheKey = `posts_latest_${limit}`;
    const cached = getFromCache<BlogPost[]>(cacheKey);
    if (cached) return cached;

    const { data } = await supabase
      .from('blogs')
      .select('*, authors(*)')
      .order('created_at', { ascending: false })
      .limit(limit);
    
    if (data) {
      setToCache(cacheKey, data);
      return data;
    }
    return [];
  },

  getDeals: async (limit: number = 3): Promise<Deal[]> => {
    const cacheKey = `deals_${limit}`;
    const cached = getFromCache<Deal[]>(cacheKey);
    if (cached) return cached;

    const { data } = await supabase
      .from('deals')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit);

    if (data) {
      setToCache(cacheKey, data);
      return data;
    }
    return [];
  },

  getPostsByCategory: async (category: string, searchTerm: string = ''): Promise<BlogPost[]> => {
    const cacheKey = searchTerm ? '' : `posts_cat_${category}`;
    if (cacheKey) {
      const cached = getFromCache<BlogPost[]>(cacheKey);
      if (cached) return cached;
    }

    let query = supabase
      .from('blogs')
      .select('*, authors(*)')
      .eq('category', category)
      .order('created_at', { ascending: false });

    if (searchTerm) {
      query = query.ilike('title', `%${searchTerm}%`);
    }

    const { data } = await query;
    if (data) {
      if (cacheKey) setToCache(cacheKey, data);
      return data;
    }
    return [];
  },

  getAllPosts: async (category: string, searchTerm: string = ''): Promise<BlogPost[]> => {
    const cacheKey = (!searchTerm && category === 'All') ? 'posts_all' : (!searchTerm ? `posts_all_${category}` : '');
    
    if (cacheKey) {
        const cached = getFromCache<BlogPost[]>(cacheKey);
        if (cached) return cached;
    }

    let query = supabase
      .from('blogs')
      .select('*, authors(*)')
      .order('created_at', { ascending: false });

    if (category !== 'All') {
      query = query.eq('category', category);
    }

    if (searchTerm) {
      query = query.ilike('title', `%${searchTerm}%`);
    }

    const { data } = await query;
    if (data) {
        if (cacheKey) setToCache(cacheKey, data);
        return data;
    }
    return [];
  },

  getPostBySlug: async (slug: string): Promise<{ post: BlogPost | null, related: BlogPost[] }> => {
    const cacheKey = `post_detail_${slug}`;
    const cached = getFromCache<{ post: BlogPost | null, related: BlogPost[] }>(cacheKey);
    if (cached) return cached;

    const isUUID = (str: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str);

    let post: BlogPost | null = null;
    
    const { data: bySlug } = await supabase
      .from('blogs')
      .select('*, authors(*)')
      .eq('slug', slug)
      .single();
    
    if (bySlug) {
      post = bySlug;
    } else if (isUUID(slug)) {
      const { data: byId } = await supabase
        .from('blogs')
        .select('*, authors(*)')
        .eq('id', slug)
        .single();
      post = byId;
    }

    let related: BlogPost[] = [];
    if (post) {
       const { data: relatedData } = await supabase
          .from('blogs')
          .select('*, authors(*)')
          .eq('category', post.category)
          .neq('id', post.id)
          .limit(3)
          .order('created_at', { ascending: false });
        if (relatedData) related = relatedData;
    }

    const result = { post, related };
    if (post) setToCache(cacheKey, result);
    
    return result;
  },

  getAuthors: async (): Promise<Author[]> => {
    const cacheKey = 'authors_list';
    const cached = getFromCache<Author[]>(cacheKey);
    if (cached) return cached;

    const { data } = await supabase
      .from('authors')
      .select('*')
      .order('created_at', { ascending: true });

    if (data) {
      setToCache(cacheKey, data);
      return data;
    }
    return [];
  },

  invalidateCache: () => {
    const prefixes = ['posts_', 'post_detail_', 'deals_', 'authors_'];
    const keysToRemove: string[] = [];
    
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && prefixes.some(prefix => key.startsWith(prefix))) {
        keysToRemove.push(key);
      }
    }
    
    keysToRemove.forEach(key => localStorage.removeItem(key));
    console.log('Cache invalidated');
  }
};
