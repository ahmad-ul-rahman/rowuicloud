
import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../utils/dataService';
import { BlogPost } from '../types';
import BlogCard from '../components/BlogCard';
import { Filter, Search } from 'lucide-react';
import SEO from '../components/SEO';

const AllPostsPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialSearch = searchParams.get('search') || '';
  
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState(initialSearch);
  const [activeFilter, setActiveFilter] = useState('All');
  
  const filters = ['All', 'Tech', 'Design', 'Tools', 'Guides'];

  useEffect(() => {
    // Update URL param when search input changes (optional but good for sharing)
    if (searchTerm) {
      setSearchParams({ search: searchTerm });
    }
  }, [searchTerm, setSearchParams]);

  useEffect(() => {
    const fetchPosts = async () => {
      setLoading(true);
      const data = await api.getAllPosts(activeFilter, searchTerm);
      if (data) setPosts(data);
      setLoading(false);
    };

    fetchPosts();
  }, [activeFilter, searchTerm]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <SEO 
        title="All Posts" 
        description="Browse all articles, guides, and resources on Row UI. Find the latest in Tech, Design, and Tools."
      />
      
      {/* Header */}
      <div className="mb-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 dark:text-white">All Articles</h1>
            <p className="mt-4 text-lg text-slate-500 dark:text-slate-400 max-w-2xl">
              Explore our complete library of design, code, and tech resources on <strong>Row UI</strong>.
            </p>
          </div>
          
          <div className="flex items-center gap-4 bg-white dark:bg-slate-800 p-2 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
            <Search className="text-slate-400 ml-2" size={20} />
            <input 
              type="text" 
              placeholder="Search articles..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-transparent border-none focus:ring-0 text-slate-700 dark:text-slate-200 w-full md:w-64"
            />
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-2 overflow-x-auto pb-6 mb-6 no-scrollbar">
        {filters.map((filter) => (
          <button 
            key={filter}
            onClick={() => setActiveFilter(filter)}
            className={`px-5 py-2.5 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
              activeFilter === filter
                ? 'bg-primary-600 text-white shadow-md shadow-primary-500/20' 
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-primary-500'
            }`}
          >
            {filter}
          </button>
        ))}
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
           {Array.from({ length: 6 }).map((_, i) => (
               <div key={i} className="h-96 bg-slate-200 dark:bg-slate-800 rounded-2xl animate-pulse"></div>
             ))}
        </div>
      ) : posts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post) => (
            <BlogCard key={post.id} post={post} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-slate-50 dark:bg-slate-900 rounded-3xl border border-dashed border-slate-300 dark:border-slate-700">
          <p className="text-xl text-slate-500 mb-2">No posts found.</p>
          <p className="text-slate-400 text-sm">Try adjusting your search or filters.</p>
        </div>
      )}
    </div>
  );
};

export default AllPostsPage;
