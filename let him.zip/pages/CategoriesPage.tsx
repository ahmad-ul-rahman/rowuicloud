
import React from 'react';
import SEO from '../components/SEO';
import { Code, Palette, PenTool, BookOpen, ArrowRight } from 'lucide-react';
import SmartLink from '../components/SmartLink';

const CategoriesPage: React.FC = () => {
  const categories = [
    {
      name: 'Tech',
      description: 'Latest in development, coding frameworks, and tech news.',
      icon: <Code size={32} />,
      color: 'bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400',
      path: '/tech'
    },
    {
      name: 'Design',
      description: 'UI/UX inspiration, trends, and case studies.',
      icon: <Palette size={32} />,
      color: 'bg-pink-50 text-pink-600 dark:bg-pink-900/20 dark:text-pink-400',
      path: '/design'
    },
    {
      name: 'Tools',
      description: 'Reviews of the best software and design tools.',
      icon: <PenTool size={32} />,
      color: 'bg-purple-50 text-purple-600 dark:bg-purple-900/20 dark:text-purple-400',
      path: '/tools'
    },
    {
      name: 'Guides',
      description: 'Step-by-step tutorials and in-depth guides.',
      icon: <BookOpen size={32} />,
      color: 'bg-green-50 text-green-600 dark:bg-green-900/20 dark:text-green-400',
      path: '/guides'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <SEO 
        title="Browse Categories" 
        description="Explore articles by category: Tech, Design, Tools, and Guides on Row UI."
      />
      
      <div className="text-center max-w-2xl mx-auto mb-16">
        <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 dark:text-white mb-4">
          Explore Categories
        </h1>
        <p className="text-xl text-slate-600 dark:text-slate-400">
          Dive into our curated content sections on Row UI to find exactly what you're looking for.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {categories.map((cat) => (
          <SmartLink 
            key={cat.name} 
            to={cat.path}
            prefetch="viewport" // Prefetch when category card appears in viewport
            className="group flex flex-col md:flex-row gap-6 p-8 bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
          >
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 ${cat.color}`}>
              {cat.icon}
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2 group-hover:text-primary-600 transition-colors">
                {cat.name}
              </h2>
              <p className="text-slate-600 dark:text-slate-400 mb-6">
                {cat.description}
              </p>
              <div className="flex items-center text-sm font-bold text-primary-600 dark:text-primary-400">
                Browse Articles <ArrowRight size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </SmartLink>
        ))}
      </div>
    </div>
  );
};

export default CategoriesPage;
