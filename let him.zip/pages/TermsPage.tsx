
import React from 'react';
import SEO from '../components/SEO';

const TermsPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 prose dark:prose-invert">
      <SEO 
        title="Terms & Conditions" 
        description="Row UI Terms and Conditions of use."
      />
      <h1>Terms & Conditions</h1>
      <p>Welcome to Row UI. By accessing our website, you agree to be bound by these Terms and Conditions.</p>
      
      <h2>1. Content Usage</h2>
      <p>All content on Row UI is for informational purposes only. Unless otherwise stated, we own the intellectual property rights for all material on Row UI. You may view and/or print pages for your own personal use.</p>
      
      <h2>2. User Comments</h2>
      <p>Parts of this website offer an opportunity for users to post and exchange opinions and information. Row UI does not filter, edit, publish or review Comments prior to their presence on the website.</p>

      <h2>3. Disclaimer</h2>
      <p>The information on this website is provided "as is," with all faults, and Row UI expresses no representations or warranties, of any kind related to this website or the materials contained on this website.</p>
    </div>
  );
};

export default TermsPage;