
import React, { useEffect } from 'react';
import SEO from '../components/SEO';

const AboutPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      <SEO 
        title="About Us" 
        description="Row UI is a premium digital publication for designers and developers. Learn about our mission and team."
      />
      
      <div className="text-center mb-16">
         <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 dark:text-white mb-6">About Row UI</h1>
         <p className="lead text-xl text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
          Row UI is a premium digital publication dedicated to the intersection of Design, Technology, and User Experience.
        </p>
      </div>

      <div className="prose prose-lg dark:prose-invert mx-auto">
        <h3>Our Mission</h3>
        <p>
          We exist to empower designers and developers with high-quality resources, in-depth tutorials, and the latest industry news. In a world of noise, Row UI signals quality. We curate the best tools, deconstruct complex UI patterns, and help you build better digital products.
        </p>

        <h3>Who We Are</h3>
        <p>
          Founded by a team of passionate UI/UX designers and senior engineers, Row UI bridges the gap between aesthetics and functionality. We believe that great software is not just about clean code—it's about the feeling it evokes in the user.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 my-12 not-prose">
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl shadow-lg border border-slate-100 dark:border-slate-800">
            <h4 className="text-xl font-bold mb-2 text-primary-600">Design</h4>
            <p className="text-slate-600 dark:text-slate-400">We obsess over pixels, typography, and micro-interactions.</p>
          </div>
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl shadow-lg border border-slate-100 dark:border-slate-800">
            <h4 className="text-xl font-bold mb-2 text-indigo-600">Technology</h4>
            <p className="text-slate-600 dark:text-slate-400">We explore the cutting-edge frameworks and tools that power the web.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;