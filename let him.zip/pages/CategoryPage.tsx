
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../utils/dataService';
import { BlogPost } from '../types';
import BlogCard from '../components/BlogCard';
import { Filter, Search } from 'lucide-react';
import SEO from '../components/SEO';

interface CategoryPageProps {
  category?: string;
}

const CategoryPage: React.FC<CategoryPageProps> = ({ category: propCategory }) => {
  const { category: paramCategory } = useParams<{ category: string }>();
  // Use prop if available (clean URL), otherwise use param (legacy URL)
  const category = propCategory || paramCategory;
  
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeSort, setActiveSort] = useState('Recent');

  useEffect(() => {
    const fetchCategoryPosts = async () => {
      setLoading(true);
      if (!category) return;

      const data = await api.getPostsByCategory(category, searchTerm);
      if (data) setPosts(data);
      setLoading(false);
    };

    fetchCategoryPosts();
  }, [category, searchTerm]);

  if (!category) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <SEO 
        title={`${category} Articles`} 
        description={`Read the latest ${category} news, tutorials, and guides on Row UI.`}
      />

      {/* Header */}
      <div className="mb-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <span className="text-primary-600 dark:text-primary-400 font-bold tracking-wider uppercase text-sm mb-2 block">Row UI Category</span>
            <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 dark:text-white">{category}</h1>
            <p className="mt-4 text-lg text-slate-500 dark:text-slate-400 max-w-2xl">
              Browse our latest <strong>Row UI</strong> articles, expert guides, and industry news specifically curated for {category}.
            </p>
          </div>
          
          <div className="flex items-center gap-4 bg-white dark:bg-slate-800 p-2 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
            <Search className="text-slate-400 ml-2" size={20} />
            <input 
              type="text" 
              placeholder={`Search in ${category}...`} 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-transparent border-none focus:ring-0 text-slate-700 dark:text-slate-200 w-full md:w-64"
            />
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-2 overflow-x-auto pb-6 mb-6 no-scrollbar">
        {['Recent', 'Popular', 'Trending'].map((filter) => (
          <button 
            key={filter} 
            onClick={() => setActiveSort(filter)}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
              activeSort === filter 
                ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900' 
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-primary-500'
            }`}
          >
            {filter}
          </button>
        ))}
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
           {Array.from({ length: 3 }).map((_, i) => (
               <div key={i} className="h-96 bg-slate-200 dark:bg-slate-800 rounded-2xl animate-pulse"></div>
             ))}
        </div>
      ) : posts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post) => (
            <BlogCard key={post.id} post={post} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20">
          <p className="text-xl text-slate-500">No posts found in {category}.</p>
        </div>
      )}
    </div>
  );
};

export default CategoryPage;
