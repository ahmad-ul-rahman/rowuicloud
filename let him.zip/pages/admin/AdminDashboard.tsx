
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Session } from '@supabase/supabase-js';
import { supabase } from '../../supabaseClient';
import { api } from '../../utils/dataService';
import { Editor } from '@tinymce/tinymce-react';
import { 
  LayoutDashboard, 
  FileText, 
  LogOut, 
  Plus, 
  Trash2, 
  Edit, 
  ChevronLeft, 
  ChevronRight, 
  Save, 
  Users, 
  UserPlus, 
  Home, 
  Menu, 
  X, 
  Search,
  ExternalLink,
  Archive,
  Download,
  Upload,
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';
import toast from 'react-hot-toast';
import { BlogPost, Author, BackupData } from '../../types';
import { generateSlug } from '../../utils/helpers';
import SEO from '../../components/SEO';
import { Link } from 'react-router-dom';
import BlurImage from '../../components/BlurImage';

interface AdminDashboardProps {
  session: Session;
}

type AdminView = 'posts' | 'authors' | 'system';

const AdminDashboard: React.FC<AdminDashboardProps> = ({ session }) => {
  const [activeView, setActiveView] = useState<AdminView>('posts');
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [authors, setAuthors] = useState<Author[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [isEditingAuthor, setIsEditingAuthor] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Dashboard UI State
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Blog Editor State
  const initialPostState: Partial<BlogPost> = {
    title: '', 
    content: '', 
    category: 'Tech', 
    image_url: '',
    author_id: '',
    slug: ''
  };
  const [currentPost, setCurrentPost] = useState<Partial<BlogPost>>(initialPostState);

  // Author Editor State
  const initialAuthorState: Partial<Author> = {
    name: '',
    profile_image: ''
  };
  const [currentAuthor, setCurrentAuthor] = useState<Partial<Author>>(initialAuthorState);

  useEffect(() => {
    fetchPosts();
    fetchAuthors();
    const checkTheme = () => {
      setIsDarkMode(document.documentElement.classList.contains('dark'));
    };
    checkTheme();
    const observer = new MutationObserver(checkTheme);
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  const fetchPosts = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('blogs')
      .select('*, authors(*)')
      .order('created_at', { ascending: false });
    
    if (error) {
      toast.error('Error fetching posts');
    } else if (data) {
      setPosts(data);
    }
    setLoading(false);
  };

  const fetchAuthors = async () => {
    const data = await api.getAuthors();
    if (data) setAuthors(data);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  // Filter and Pagination Logic
  const filteredPosts = useMemo(() => {
    return posts.filter(post => 
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.category.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [posts, searchTerm]);

  const paginatedPosts = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredPosts.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredPosts, currentPage]);

  const totalPages = Math.ceil(filteredPosts.length / itemsPerPage);

  // --- BLOG CRUD ---
  const handleSavePost = async () => {
    const title = currentPost.title?.trim();
    const authorId = currentPost.author_id;

    if (!title || !authorId) {
      toast.error('Title and Author are required');
      return;
    }

    let baseSlug = currentPost.slug;
    if (!baseSlug || baseSlug.trim() === '') {
      baseSlug = generateSlug(title);
    }
    if (!baseSlug) baseSlug = `post-${Date.now()}`;

    let finalSlug = baseSlug;
    let counter = 1;
    while (posts.some(p => p.slug === finalSlug && p.id !== currentPost.id)) {
        finalSlug = `${baseSlug}-${counter}`;
        counter++;
    }

    const postData = {
      title: title,
      slug: finalSlug,
      content: currentPost.content || '',
      category: currentPost.category || 'Tech',
      author_id: authorId,
      image_url: currentPost.image_url || 'https://picsum.photos/800/600',
      created_at: currentPost.created_at || new Date().toISOString()
    };

    setLoading(true);
    let error;
    if (currentPost.id) {
       const { error: updateError } = await supabase.from('blogs').update(postData).eq('id', currentPost.id);
       error = updateError;
    } else {
       const { error: insertError } = await supabase.from('blogs').insert([postData]);
       error = insertError;
    }
    setLoading(false);

    if (error) {
      toast.error('Error saving post: ' + error.message);
    } else {
      toast.success(currentPost.id ? 'Post updated!' : 'Post created!');
      api.invalidateCache();
      setIsEditing(false);
      setCurrentPost(initialPostState);
      fetchPosts();
    }
  };

  const handleDeletePost = async (id: string) => {
    if (!window.confirm('Delete this post?')) return;
    setLoading(true);
    const { error } = await supabase.from('blogs').delete().eq('id', id);
    setLoading(false);
    if (error) toast.error('Error deleting post');
    else {
      toast.success('Post deleted');
      api.invalidateCache();
      fetchPosts();
    }
  };

  // --- AUTHOR CRUD ---
  const handleSaveAuthor = async () => {
    const name = currentAuthor.name?.trim();
    if (!name) {
      toast.error('Name is required');
      return;
    }

    const authorData = {
      name: name,
      profile_image: currentAuthor.profile_image || `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random`
    };

    setLoading(true);
    let error;
    if (currentAuthor.uuid) {
       const { error: updateError } = await supabase.from('authors').update(authorData).eq('uuid', currentAuthor.uuid);
       error = updateError;
    } else {
       const { error: insertError } = await supabase.from('authors').insert([authorData]);
       error = insertError;
    }
    setLoading(false);

    if (error) {
      toast.error('Error saving author: ' + error.message);
    } else {
      toast.success(currentAuthor.uuid ? 'Author updated!' : 'Author created!');
      api.invalidateCache();
      setIsEditingAuthor(false);
      setCurrentAuthor(initialAuthorState);
      fetchAuthors();
    }
  };

  const handleDeleteAuthor = async (uuid: string) => {
    if (!window.confirm('Delete this author? Blogs by this author might lose linkage.')) return;
    setLoading(true);
    const { error } = await supabase.from('authors').delete().eq('uuid', uuid);
    setLoading(false);
    if (error) toast.error('Error deleting author');
    else {
      toast.success('Author deleted');
      api.invalidateCache();
      fetchAuthors();
    }
  };

  // --- RESTORE POINT LOGIC ---
  const handleCreateRestorePoint = async () => {
    setLoading(true);
    try {
      // Fetch fresh data for both authors and blogs
      const { data: authorsData } = await supabase.from('authors').select('*');
      const { data: blogsData } = await supabase.from('blogs').select('*');

      const backup: BackupData = {
        version: '1.0',
        timestamp: new Date().toISOString(),
        authors: authorsData || [],
        blogs: blogsData || []
      };

      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `rowui-restore-point-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast.success('Restore point created and downloaded!');
    } catch (err) {
      toast.error('Failed to create restore point');
    } finally {
      setLoading(false);
    }
  };

  const handleImportRestorePoint = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target?.result as string) as BackupData;
        
        // Basic validation
        if (!json.authors || !json.blogs) {
          throw new Error('Invalid restore point format');
        }

        const confirmMessage = `WARNING: This will merge/overwrite current data with ${json.blogs.length} blogs and ${json.authors.length} authors from the restore point dated ${new Date(json.timestamp).toLocaleString()}. Proceed?`;
        
        if (!window.confirm(confirmMessage)) return;

        setLoading(true);

        // 1. Restore Authors first (due to Foreign Key constraints)
        // Note: Clean authors data before upsert (remove timestamps if needed, or keep them)
        const { error: authorErr } = await supabase.from('authors').upsert(json.authors);
        if (authorErr) throw authorErr;

        // 2. Restore Blogs
        // We strip the joined 'authors' object if it exists to avoid Supabase errors on upsert
        const cleanBlogs = json.blogs.map(b => {
          const { authors, ...rest } = b as any;
          return rest;
        });
        const { error: blogErr } = await supabase.from('blogs').upsert(cleanBlogs);
        if (blogErr) throw blogErr;

        toast.success('Restore point applied successfully!');
        api.invalidateCache();
        fetchPosts();
        fetchAuthors();
      } catch (err: any) {
        console.error(err);
        toast.error('Failed to apply restore point: ' + err.message);
      } finally {
        setLoading(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  const startEditPost = (post: BlogPost) => {
    setCurrentPost({
      ...post,
      title: post.title || '',
      content: post.content || '',
      author_id: post.author_id || post.authors?.uuid || '',
      slug: post.slug || '',
      image_url: post.image_url || '',
      category: post.category || 'Tech'
    });
    setIsEditing(true);
    window.scrollTo(0, 0);
  };

  const startNewPost = () => {
    setCurrentPost({
      ...initialPostState,
      author_id: authors.length > 0 ? authors[0].uuid : ''
    });
    setIsEditing(true);
  };

  const startEditAuthor = (author: Author) => {
    setCurrentAuthor({
      ...author,
      name: author.name || '',
      profile_image: author.profile_image || ''
    });
    setIsEditingAuthor(true);
  };

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-950 font-sans">
      <SEO title="Admin Dashboard" description="Manage your content" />
      
      {/* Sidebar Overlay for Mobile */}
      {!isSidebarOpen && (
        <button 
          onClick={() => setIsSidebarOpen(true)}
          className="fixed top-4 left-4 z-50 p-2 bg-white dark:bg-slate-900 rounded-lg shadow-md border border-slate-200 dark:border-slate-800 md:hidden"
        >
          <Menu size={20} />
        </button>
      )}

      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-40 w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 transform transition-transform duration-300 ease-in-out ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0`}>
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <LayoutDashboard className="text-primary-600" size={24} />
              Admin UI
            </h2>
            <button onClick={() => setIsSidebarOpen(false)} className="md:hidden p-1 text-slate-400 hover:text-slate-600">
              <X size={20} />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
            <button
              onClick={() => { setActiveView('posts'); setIsEditing(false); setIsEditingAuthor(false); }}
              className={`w-full flex items-center px-4 py-3 rounded-xl text-left transition-colors ${
                activeView === 'posts' && !isEditing 
                  ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 font-bold' 
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <FileText size={20} className="mr-3" />
              Manage Blogs
            </button>
            
            <button
              onClick={() => { setActiveView('authors'); setIsEditing(false); setIsEditingAuthor(false); }}
              className={`w-full flex items-center px-4 py-3 rounded-xl text-left transition-colors ${
                activeView === 'authors' && !isEditingAuthor
                  ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 font-bold' 
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <Users size={20} className="mr-3" />
              Manage Authors
            </button>

            <button
              onClick={() => { setActiveView('system'); setIsEditing(false); setIsEditingAuthor(false); }}
              className={`w-full flex items-center px-4 py-3 rounded-xl text-left transition-colors ${
                activeView === 'system'
                  ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 font-bold' 
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <Archive size={20} className="mr-3" />
              System & Backups
            </button>
          </nav>

          {/* Sidebar Footer */}
          <div className="p-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <Link
              to="/"
              className="w-full flex items-center px-4 py-3 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors font-medium"
            >
              <Home size={20} className="mr-3" />
              Return Home
            </Link>
            <button
              onClick={handleLogout}
              className="w-full flex items-center px-4 py-3 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-xl transition-colors font-medium"
            >
              <LogOut size={20} className="mr-3" />
              Sign Out
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Header / Bar */}
        <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-4 md:px-8 shrink-0">
          <div className="flex items-center gap-4 flex-1">
             <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="hidden md:block p-2 text-slate-400 hover:text-slate-600">
               <Menu size={20} />
             </button>
             
             {/* Dynamic Search Bar (only in list views) */}
             {!isEditing && !isEditingAuthor && activeView === 'posts' && (
               <div className="relative max-w-md w-full ml-4">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    placeholder="Search by title or category..."
                    value={searchTerm}
                    onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
                    className="w-full pl-10 pr-4 py-2 bg-slate-100 dark:bg-slate-800 border-none rounded-lg focus:ring-2 focus:ring-primary-500 text-sm transition-all"
                  />
               </div>
             )}
          </div>

          <div className="flex items-center gap-4">
             <span className="hidden sm:inline-block text-xs font-medium text-slate-400 px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-full border border-slate-200 dark:border-slate-700">
               Logged in as Admin
             </span>
          </div>
        </header>

        {/* Scrollable Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8">
          {activeView === 'posts' && (
            isEditing ? (
              <div className="max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-300">
                <div className="flex items-center justify-between mb-8">
                  <button onClick={() => setIsEditing(false)} className="flex items-center text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition-colors">
                    <ChevronLeft size={20} className="mr-1" /> Back to Posts
                  </button>
                  <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{currentPost.id ? 'Edit Post' : 'New Post'}</h1>
                </div>

                <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-6">
                      <div>
                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Post Title</label>
                        <input
                          type="text"
                          placeholder="Enter a catchy title..."
                          value={currentPost.title || ''}
                          onChange={(e) => {
                            const title = e.target.value;
                            const slug = generateSlug(title);
                            setCurrentPost({ ...currentPost, title, slug });
                          }}
                          className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-primary-500 outline-none transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">URL Slug</label>
                        <div className="flex items-center">
                          <span className="bg-slate-100 dark:bg-slate-800 border border-r-0 border-slate-200 dark:border-slate-700 text-slate-500 px-3 py-3 rounded-l-xl text-sm">/blog/</span>
                          <input
                            type="text"
                            placeholder="post-url-slug"
                            value={currentPost.slug || ''}
                            onChange={(e) => setCurrentPost({ ...currentPost, slug: e.target.value })}
                            className="flex-1 text-sm px-4 py-3 rounded-r-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 outline-none focus:ring-2 focus:ring-primary-500"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Category</label>
                        <select
                          value={currentPost.category}
                          onChange={(e) => setCurrentPost({ ...currentPost, category: e.target.value as any })}
                          className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-primary-500 outline-none"
                        >
                          <option value="Tech">Tech</option>
                          <option value="Design">Design</option>
                          <option value="Tools">Tools</option>
                          <option value="Guides">Guides</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Author</label>
                        <select
                          value={currentPost.author_id || ''}
                          onChange={(e) => setCurrentPost({ ...currentPost, author_id: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-primary-500 outline-none"
                        >
                          <option value="" disabled>Select an author</option>
                          {authors.map(a => (
                            <option key={a.uuid} value={a.uuid}>{a.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="space-y-6">
                      <div>
                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Main Image URL</label>
                        <input 
                          type="url" 
                          placeholder="https://..."
                          value={currentPost.image_url || ''}
                          onChange={(e) => setCurrentPost({ ...currentPost, image_url: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-primary-500 outline-none"
                        />
                      </div>
                      
                      <div className="aspect-[16/9] w-full bg-slate-100 dark:bg-slate-800 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 flex items-center justify-center relative shadow-inner">
                         {currentPost.image_url ? (
                           <BlurImage src={currentPost.image_url} alt="Preview" containerClassName="w-full h-full" className="w-full h-full object-cover" />
                         ) : (
                           <div className="text-slate-400 flex flex-col items-center">
                             <FileText size={48} className="mb-2 opacity-20" />
                             <span className="text-sm font-medium">No Image Preview</span>
                           </div>
                         )}
                      </div>
                    </div>
                  </div>

                  <div>
                     <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Content (Optional)</label>
                     <div className="rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700">
                      <Editor
                        key={isDarkMode ? 'dark' : 'light'}
                        apiKey="x2w7yw84n0wynhag4o9330f3vd6yjkep7pthqfyyk2g2ckc7"
                        value={currentPost.content || ''}
                        onEditorChange={(content) => setCurrentPost({ ...currentPost, content })}
                        init={{
                          height: 500, menubar: false,
                          plugins: ['advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview', 'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen', 'insertdatetime', 'media', 'table', 'code', 'help', 'wordcount'],
                          toolbar: 'undo redo | blocks | bold italic forecolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image code | removeformat',
                          skin: isDarkMode ? 'oxide-dark' : 'oxide',
                          content_css: isDarkMode ? 'dark' : 'default',
                          promotion: false,
                          relative_urls: false,
                          remove_script_host: false,
                          convert_urls: false
                        }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                    <button onClick={() => setIsEditing(false)} className="px-6 py-3 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 font-medium transition-colors">Cancel</button>
                    <button onClick={handleSavePost} disabled={loading} className="px-8 py-3 rounded-xl bg-primary-600 text-white hover:bg-primary-700 font-bold shadow-lg shadow-primary-500/20 transition-all flex items-center gap-2"><Save size={18} />{loading ? 'Saving...' : 'Save Post'}</button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="animate-in fade-in duration-500">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                  <div>
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Blog Posts</h1>
                    <p className="text-slate-500 dark:text-slate-400 mt-1">
                      {filteredPosts.length} post{filteredPosts.length !== 1 ? 's' : ''} found.
                    </p>
                  </div>
                  <button onClick={startNewPost} className="flex items-center justify-center px-6 py-3 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-colors font-bold shadow-lg shadow-primary-500/25">
                    <Plus size={20} className="mr-2" /> Add New Post
                  </button>
                </div>

                <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden mb-8">
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-800">
                      <thead className="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                          <th className="px-6 py-5 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">Preview</th>
                          <th className="px-6 py-5 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">Details</th>
                          <th className="px-6 py-5 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">Category</th>
                          <th className="px-6 py-5 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">Author</th>
                          <th className="px-6 py-5 text-right text-xs font-bold text-slate-400 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white dark:bg-slate-900 divide-y divide-slate-200 dark:divide-slate-800">
                        {paginatedPosts.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="px-6 py-20 text-center">
                               <div className="flex flex-col items-center opacity-40">
                                 <FileText size={48} className="mb-4" />
                                 <p className="text-lg font-medium text-slate-500">No blog posts found</p>
                               </div>
                            </td>
                          </tr>
                        ) : (
                          paginatedPosts.map((post) => (
                            <tr key={post.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group">
                              <td className="px-6 py-4 whitespace-nowrap">
                                <BlurImage src={post.image_url} alt="" containerClassName="h-12 w-20 rounded-lg shadow-sm border border-slate-100 dark:border-slate-700" className="h-full w-full object-cover" />
                              </td>
                              <td className="px-6 py-4">
                                <div className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-primary-600 transition-colors">{post.title}</div>
                                <div className="text-xs text-slate-400 mt-1 flex items-center gap-1">
                                  {post.slug}
                                  <Link to={`/blog/${post.slug}`} target="_blank" className="text-primary-500 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <ExternalLink size={10} />
                                  </Link>
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                                  {post.category}
                                </span>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 font-medium">
                                {post.authors?.name || 'N/A'}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <div className="flex justify-end gap-2">
                                  <button onClick={() => startEditPost(post)} className="p-2 text-slate-400 hover:text-primary-600 hover:bg-primary-50 dark:hover:bg-primary-900/20 rounded-lg transition-all" title="Edit">
                                    <Edit size={18} />
                                  </button>
                                  <button onClick={() => handleDeletePost(post.id)} className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all" title="Delete">
                                    <Trash2 size={18} />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Pagination Controls */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-between bg-white dark:bg-slate-900 px-6 py-4 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
                    <p className="text-sm text-slate-500">
                      Showing <span className="font-bold text-slate-900 dark:text-white">{(currentPage - 1) * itemsPerPage + 1}</span> to <span className="font-bold text-slate-900 dark:text-white">{Math.min(currentPage * itemsPerPage, filteredPosts.length)}</span> of <span className="font-bold text-slate-900 dark:text-white">{filteredPosts.length}</span> results
                    </p>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        disabled={currentPage === 1}
                        className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-30 transition-colors"
                      >
                        <ChevronLeft size={20} />
                      </button>
                      <div className="flex items-center gap-1">
                        {Array.from({ length: totalPages }).map((_, i) => (
                          <button
                            key={i}
                            onClick={() => setCurrentPage(i + 1)}
                            className={`w-10 h-10 rounded-lg text-sm font-bold transition-all ${
                              currentPage === i + 1 
                                ? 'bg-primary-600 text-white shadow-md shadow-primary-500/20' 
                                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                            }`}
                          >
                            {i + 1}
                          </button>
                        ))}
                      </div>
                      <button 
                        onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                        disabled={currentPage === totalPages}
                        className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-30 transition-colors"
                      >
                        <ChevronRight size={20} />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )
          )}

          {activeView === 'authors' && (
            isEditingAuthor ? (
              <div className="max-w-2xl mx-auto animate-in slide-in-from-bottom-4 duration-300">
                 <div className="flex items-center justify-between mb-8">
                  <button onClick={() => setIsEditingAuthor(false)} className="flex items-center text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition-colors">
                    <ChevronLeft size={20} className="mr-1" /> Back to Authors
                  </button>
                  <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{currentAuthor.uuid ? 'Edit Author' : 'New Author'}</h1>
                </div>

                <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 space-y-6">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Author Name</label>
                    <input
                      type="text"
                      value={currentAuthor.name || ''}
                      onChange={(e) => setCurrentAuthor({ ...currentAuthor, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-primary-500 outline-none transition-all"
                      placeholder="Author's full name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Profile Image URL</label>
                    <input
                      type="url"
                      value={currentAuthor.profile_image || ''}
                      onChange={(e) => setCurrentAuthor({ ...currentAuthor, profile_image: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-primary-500 outline-none transition-all"
                      placeholder="https://..."
                    />
                  </div>
                  <div className="flex items-center justify-end gap-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                    <button onClick={() => setIsEditingAuthor(false)} className="px-6 py-3 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 font-medium transition-colors">Cancel</button>
                    <button onClick={handleSaveAuthor} disabled={loading} className="px-8 py-3 rounded-xl bg-primary-600 text-white hover:bg-primary-700 font-bold shadow-lg shadow-primary-500/20 transition-all flex items-center gap-2"><Save size={18} />{loading ? 'Saving...' : 'Save Author'}</button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="animate-in fade-in duration-500">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                  <div>
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Authors</h1>
                    <p className="text-slate-500 dark:text-slate-400 mt-1">Manage the people behind your Row UI stories.</p>
                  </div>
                  <button onClick={() => { setCurrentAuthor(initialAuthorState); setIsEditingAuthor(true); }} className="flex items-center justify-center px-6 py-3 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors font-bold shadow-lg shadow-indigo-500/25">
                    <UserPlus size={20} className="mr-2" /> Add New Author
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {authors.map(author => (
                    <div key={author.uuid} className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 flex items-center gap-4 group transition-all hover:shadow-xl hover:-translate-y-1">
                      <BlurImage 
                        src={author.profile_image} 
                        alt={author.name} 
                        noScale={true}
                        loading="lazy"
                        decoding="async"
                        containerClassName="h-16 w-16 rounded-full shadow-inner border border-white/20 shrink-0"
                        className="h-full w-full object-cover rounded-full"
                      />
                      <div className="flex-1">
                        <h3 className="font-bold text-lg text-slate-900 dark:text-white">{author.name}</h3>
                        <p className="text-xs text-slate-500 font-medium">Joined {new Date(author.created_at).toLocaleDateString()}</p>
                      </div>
                      <div className="flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => startEditAuthor(author)} className="p-2 text-slate-400 hover:text-primary-600 hover:bg-primary-50 dark:hover:bg-primary-900/20 rounded-lg transition-all"><Edit size={16} /></button>
                        <button onClick={() => handleDeleteAuthor(author.uuid)} className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all"><Trash2 size={16} /></button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )
          )}
          {/* ... existing system view remains unchanged ... */}
          {activeView === 'system' && (
            <div className="max-w-4xl mx-auto animate-in fade-in duration-500">
               <div className="mb-10">
                  <h1 className="text-3xl font-bold text-slate-900 dark:text-white">System & Restore Points</h1>
                  <p className="text-slate-500 dark:text-slate-400 mt-1">Maintain the integrity of your Row UI platform content.</p>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Create Restore Point Card */}
                  <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 flex flex-col h-full">
                     <div className="w-14 h-14 bg-primary-100 dark:bg-primary-900/30 rounded-2xl flex items-center justify-center mb-6 text-primary-600 dark:text-primary-400">
                        <Download size={28} />
                     </div>
                     <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3">Create Restore Point</h3>
                     <p className="text-slate-500 dark:text-slate-400 mb-8 flex-1">
                        Download a complete snapshot of all blog posts and authors. We recommend doing this before major content shifts.
                     </p>
                     <div className="space-y-4">
                        <div className="flex items-center gap-3 text-xs font-medium text-slate-400 py-3 px-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                           <ShieldCheck size={16} className="text-green-500" />
                           Your data is packaged into a secure JSON bundle.
                        </div>
                        <button 
                          onClick={handleCreateRestorePoint}
                          disabled={loading}
                          className="w-full py-4 bg-primary-600 hover:bg-primary-700 text-white rounded-xl font-bold transition-all shadow-lg shadow-primary-500/25 flex items-center justify-center gap-2"
                        >
                           {loading ? 'Processing...' : <><Download size={18} /> Download Snapshot</>}
                        </button>
                     </div>
                  </div>

                  {/* Apply Restore Point Card */}
                  <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 flex flex-col h-full">
                     <div className="w-14 h-14 bg-amber-100 dark:bg-amber-900/30 rounded-2xl flex items-center justify-center mb-6 text-amber-600 dark:text-amber-400">
                        <Upload size={28} />
                     </div>
                     <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3">Apply Restore Point</h3>
                     <p className="text-slate-500 dark:text-slate-400 mb-8 flex-1">
                        Restore your blog to a previous state by uploading a valid snapshot file. This will merge and update your current data.
                     </p>
                     <div className="space-y-4">
                        <div className="flex items-center gap-3 text-xs font-medium text-amber-600 dark:text-amber-400 py-3 px-4 bg-amber-50 dark:bg-amber-900/10 rounded-xl border border-amber-100 dark:border-amber-900/30">
                           <AlertTriangle size={16} />
                           Caution: This can overwrite existing content.
                        </div>
                        <input 
                           type="file" 
                           ref={fileInputRef}
                           accept=".json"
                           onChange={handleImportRestorePoint}
                           className="hidden" 
                        />
                        <button 
                          onClick={() => fileInputRef.current?.click()}
                          disabled={loading}
                          className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-bold transition-all flex items-center justify-center gap-2 hover:opacity-90"
                        >
                           {loading ? 'Applying...' : <><Upload size={18} /> Upload Snapshot</>}
                        </button>
                     </div>
                  </div>
               </div>

               {/* Health Monitor */}
               <div className="mt-12 bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800">
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-6">Database Health</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                     <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Total Blogs</p>
                        <p className="text-2xl font-extrabold text-slate-900 dark:text-white">{posts.length}</p>
                     </div>
                     <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Total Authors</p>
                        <p className="text-2xl font-extrabold text-slate-900 dark:text-white">{authors.length}</p>
                     </div>
                     <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Latest Update</p>
                        <p className="text-sm font-bold text-slate-900 dark:text-white">
                          {posts.length > 0 ? new Date(posts[0].created_at).toLocaleDateString() : 'N/A'}
                        </p>
                     </div>
                     <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">System Version</p>
                        <p className="text-sm font-bold text-slate-900 dark:text-white">v1.0.4-LATEST</p>
                     </div>
                  </div>
               </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;
