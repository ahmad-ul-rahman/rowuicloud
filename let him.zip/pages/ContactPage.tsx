
import React, { useState } from 'react';
import { supabase } from '../supabaseClient';
import toast from 'react-hot-toast';
import { Send, Mail, MapPin, Phone } from 'lucide-react';
import SEO from '../components/SEO';

const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    topic: 'General Inquiry',
    message: ''
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Basic Validation
    if (!formData.name || !formData.email || !formData.message) {
      toast.error('Please fill in all fields.');
      setLoading(false);
      return;
    }

    try {
      const { error } = await supabase.from('Contact Messages').insert([
        { 
          name: formData.name,
          email: formData.email,
          topic: formData.topic,
          message: formData.message,
        }
      ]);

      if (error) throw error;
      
      toast.success('Message sent successfully!');
      setFormData({ name: '', email: '', topic: 'General Inquiry', message: '' });
    } catch (error: any) {
      console.error(error);
      toast.error('Failed to send message: ' + (error.message || 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <SEO 
        title="Contact Us" 
        description="Get in touch with the Row UI team for support, feedback, or partnership opportunities."
      />

      {/* Header Section */}
      <div className="bg-white dark:bg-slate-900 py-20 border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-extrabold text-slate-900 dark:text-white mb-6 tracking-tight">
            Let's Connect
          </h1>
          <p className="text-xl text-slate-500 dark:text-slate-400 max-w-2xl mx-auto font-medium">
            Have a question about UI design, code, or our latest articles? Our team is here to help you refine your digital craft.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          
          {/* Contact Info Sidebar */}
          <div className="space-y-8">
            <div className="bg-white dark:bg-slate-900 p-10 rounded-[40px] shadow-sm border border-slate-200 dark:border-slate-800">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-8 uppercase tracking-widest">Connect</h3>
              
              <div className="space-y-8">
                <div className="flex items-start gap-5">
                  <div className="p-4 bg-primary-50 dark:bg-primary-900/20 rounded-2xl text-primary-600 dark:text-primary-400">
                    <Mail size={24} />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white mb-1">Email Our Team</p>
                    <a href="mailto:info@rowui.com" className="text-slate-500 dark:text-slate-400 hover:text-primary-500 transition-colors font-medium">info@rowui.com</a>
                  </div>
                </div>

                <div className="flex items-start gap-5 opacity-40 grayscale">
                  <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-2xl text-slate-400">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white mb-1">Global Presence</p>
                    <p className="text-slate-500 dark:text-slate-400 text-sm">Serving the worldwide <br/>design community.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-slate-900 dark:bg-indigo-600 rounded-[40px] p-10 text-white relative overflow-hidden shadow-2xl">
               <div className="relative z-10">
                 <h3 className="text-2xl font-extrabold mb-3">Enterprise Solutions?</h3>
                 <p className="text-slate-300 dark:text-indigo-100 text-sm mb-8 leading-relaxed font-medium">Reach a highly targeted audience of over 50,000 monthly designers and developers.</p>
                 <button className="w-full bg-white text-slate-900 dark:text-indigo-600 py-4 rounded-2xl font-black hover:bg-slate-100 transition-all active:scale-95 shadow-lg">
                   Download Media Kit
                 </button>
               </div>
               <div className="absolute top-0 right-0 -mr-8 -mt-8 w-40 h-40 bg-white opacity-[0.05] rounded-full blur-3xl"></div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="bg-white dark:bg-slate-900 p-8 md:p-12 rounded-[40px] shadow-2xl border border-slate-200 dark:border-slate-800 space-y-10">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="space-y-3">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Your Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Enter your name"
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border-2 border-transparent focus:border-primary-500 focus:bg-white dark:focus:bg-slate-900 outline-none transition-all font-bold text-slate-900 dark:text-white placeholder:text-slate-400"
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div className="space-y-3">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="name@company.com"
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border-2 border-transparent focus:border-primary-500 focus:bg-white dark:focus:bg-slate-900 outline-none transition-all font-bold text-slate-900 dark:text-white placeholder:text-slate-400"
                    value={formData.email}
                    onChange={e => setFormData({...formData, email: e.target.value})}
                  />
                </div>
              </div>
              
              <div className="space-y-3">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Reason for Inquiry</label>
                <div className="relative">
                  <select
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border-2 border-transparent focus:border-primary-500 focus:bg-white dark:focus:bg-slate-900 outline-none transition-all font-bold text-slate-900 dark:text-white appearance-none cursor-pointer"
                    value={formData.topic}
                    onChange={e => setFormData({...formData, topic: e.target.value})}
                  >
                    <option>General Inquiry</option>
                    <option>Editorial Collaboration</option>
                    <option>Technical Support</option>
                    <option>Advertising & Sponsorship</option>
                  </select>
                  <div className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Your Message</label>
                <textarea
                  required
                  rows={6}
                  placeholder="How can our team help you?"
                  className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border-2 border-transparent focus:border-primary-500 focus:bg-white dark:focus:bg-slate-900 outline-none transition-all font-bold text-slate-900 dark:text-white resize-none placeholder:text-slate-400"
                  value={formData.message}
                  onChange={e => setFormData({...formData, message: e.target.value})}
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-slate-900 dark:bg-primary-600 hover:bg-black dark:hover:bg-primary-700 text-white font-black py-5 rounded-2xl transition-all shadow-xl shadow-primary-500/20 flex items-center justify-center gap-3 disabled:opacity-70 disabled:cursor-not-allowed transform active:scale-[0.98]"
              >
                {loading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>Processing Message...</span>
                  </>
                ) : (
                  <>
                    <Send size={20} />
                    <span>Send Message</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
