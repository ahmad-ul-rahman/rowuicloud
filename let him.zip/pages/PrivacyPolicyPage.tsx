
import React from 'react';
import SEO from '../components/SEO';

const PrivacyPolicyPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 prose dark:prose-invert">
      <SEO 
        title="Privacy Policy" 
        description="Row UI Privacy Policy - How we collect and protect your data."
      />
      <h1>Privacy Policy</h1>
      <p>Last updated: {new Date().toLocaleDateString()}</p>
      <p>At Row UI, we take your privacy seriously. This Privacy Policy explains how we collect, use, and protect your personal information.</p>
      
      <h2>1. Information We Collect</h2>
      <p>We collect information you provide directly to us, such as when you subscribe to our newsletter, fill out a contact form, or comment on a post. This may include your name, email address, and any other information you choose to provide.</p>
      
      <h2>2. How We Use Your Information</h2>
      <p>We use the information we collect to:</p>
      <ul>
        <li>Provide, maintain, and improve our website.</li>
        <li>Send you newsletters and updates if you have subscribed.</li>
        <li>Respond to your comments and questions.</li>
      </ul>

      <h2>3. Data Security</h2>
      <p>We implement appropriate security measures to protect your personal information. However, no method of transmission over the Internet is 100% secure.</p>
    </div>
  );
};

export default PrivacyPolicyPage;