
import React, { useEffect, useState } from 'react';
import { Zap, ArrowRight, ChevronRight, Layout, Cpu, Sparkles } from 'lucide-react';
import { api } from '../utils/dataService';
import { BlogPost, Deal } from '../types';
import BlogCard from '../components/BlogCard';
import SmartLink from '../components/SmartLink';
import SEO from '../components/SEO';

const HomePage: React.FC = () => {
  const [latestPosts, setLatestPosts] = useState<BlogPost[]>([]);
  const [deals, setDeals] = useState<Deal[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      // Fetch exactly 6 posts for a perfect 3x2 grid
      const posts = await api.getLatestPosts(6);

      if (posts) {
        setLatestPosts(posts);
      }

      const fetchedDeals = await api.getDeals(3);
      if (fetchedDeals) setDeals(fetchedDeals);
      
      setLoading(false);
    };

    fetchData();
  }, []);

  return (
    <div className="space-y-32 pb-24">
      <SEO 
        title="Row UI - Premium Insights for Modern Builders" 
        description="Row UI is a premier destination for UI/UX Design, Modern Development, and Digital Strategy. Elevate your craft with our curated blogs."
      />

      {/* Professional Hero Section */}
      <section className="relative pt-24 lg:pt-48 pb-24 overflow-hidden">
        {/* Advanced Mesh Gradient Background */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[800px] pointer-events-none select-none">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(14,165,233,0.08),transparent_70%)]" />
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary-500/10 rounded-full blur-[120px] opacity-60" />
          <div className="absolute bottom-[20%] right-[-5%] w-[30%] h-[30%] bg-indigo-500/10 rounded-full blur-[100px] opacity-40" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative text-center">
          <div className="max-w-4xl mx-auto">
            {/* Premium Badge */}
            <div className="inline-flex items-center gap-2.5 py-2 px-5 rounded-full bg-white/80 dark:bg-slate-900/50 backdrop-blur-md text-slate-600 dark:text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] mb-10 border border-slate-200/50 dark:border-white/5 mx-auto shadow-sm">
              <Sparkles size={12} className="text-primary-500" />
              <span>Redefining the Standard of Excellence</span>
            </div>
            
            <h1 className="text-5xl md:text-[84px] font-extrabold tracking-[-0.04em] text-slate-900 dark:text-white mb-10 leading-[1.05] max-w-4xl mx-auto">
              Mastering the Art of <br className="hidden md:block"/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-600 via-primary-500 to-indigo-600">
                Digital Precision.
              </span>
            </h1>
            
            <p className="text-lg md:text-xl text-slate-500 dark:text-slate-400 mb-14 max-w-2xl mx-auto leading-relaxed font-medium">
              Row UI is a blog dedicated to design, development, and the tools that power modern websites. We share practical articles, honest reviews, and clear breakdowns to help you build better, faster, and cleaner web experiences.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-6">
              <SmartLink to="/posts" prefetch="hover" className="px-12 py-5 rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold shadow-2xl shadow-slate-900/20 dark:shadow-white/10 hover:translate-y-[-2px] active:scale-95 transition-all flex items-center gap-3">
                Explore The Archive <ArrowRight size={20} />
              </SmartLink>
              <SmartLink to="/categories" prefetch="hover" className="px-12 py-5 rounded-2xl bg-white dark:bg-slate-800/40 backdrop-blur-md border border-slate-200 dark:border-slate-700/50 font-bold hover:bg-slate-50 dark:hover:bg-slate-700 active:scale-95 transition-all text-slate-700 dark:text-slate-200 flex items-center gap-3">
                <Layout size={18} /> Categories
              </SmartLink>
            </div>

            {/* Subtle Social Proof */}
            <div className="mt-32 pt-12 border-t border-slate-200/50 dark:border-white/5 flex flex-wrap justify-center gap-12 md:gap-24 opacity-30 grayscale hover:grayscale-0 transition-all duration-700">
                <div className="flex items-center gap-3 text-sm font-black tracking-widest uppercase"><Cpu size={20}/> Architecture</div>
                <div className="flex items-center gap-3 text-sm font-black tracking-widest uppercase"><Layout size={20}/> Interface</div>
                <div className="flex items-center gap-3 text-sm font-black tracking-widest uppercase"><Sparkles size={20}/> Ecosystem</div>
            </div>
          </div>
        </div>
      </section>

      {/* Latest Insights Grid - Exactly 6 items */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 gap-6">
          <div className="max-w-xl">
            <h2 className="text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">Latest Insights</h2>
            <div className="h-1.5 w-12 bg-primary-500 mt-4 rounded-full" />
            <p className="text-slate-500 dark:text-slate-400 mt-6 text-lg font-medium leading-relaxed">
              Perspective on the technologies and methodologies shaping the modern industry.
            </p>
          </div>
          <SmartLink to="/posts" prefetch="hover" className="group flex items-center gap-2 text-primary-600 dark:text-primary-400 font-black uppercase tracking-widest text-sm bg-primary-50 dark:bg-primary-900/20 px-6 py-4 rounded-2xl hover:bg-primary-600 hover:text-white transition-all shadow-sm">
            Browse All Posts <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </SmartLink>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {loading ? (
             Array.from({ length: 6 }).map((_, i) => (
               <div key={i} className="h-[450px] bg-slate-200 dark:bg-slate-800 rounded-[32px] animate-pulse"></div>
             ))
          ) : (
            latestPosts.map((post) => (
              <BlogCard key={post.id} post={post} />
            ))
          )}
        </div>
      </section>

      {/* Deals Section */}
      {deals.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-900 dark:bg-slate-900 rounded-[48px] p-8 md:p-16 lg:p-20 text-white relative overflow-hidden border border-white/5 shadow-3xl">
            <div className="absolute top-0 right-0 p-64 bg-primary-500/20 rounded-full blur-[120px] mix-blend-screen pointer-events-none" />
            <div className="absolute bottom-0 left-0 p-64 bg-indigo-500/20 rounded-full blur-[120px] mix-blend-screen pointer-events-none" />

            <div className="relative z-10">
              <div className="flex items-center gap-4 mb-12">
                <div className="w-12 h-12 rounded-2xl bg-yellow-400/20 flex items-center justify-center border border-yellow-400/20">
                  <Zap className="text-yellow-400" size={24} />
                </div>
                <h2 className="text-4xl font-extrabold tracking-tight">Exclusive Deals</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {deals.map((deal) => (
                  <div key={deal.id} className="bg-white/5 backdrop-blur-xl rounded-3xl p-8 border border-white/10 hover:border-white/30 transition-all group">
                    <div className="w-14 h-14 bg-white rounded-2xl mb-8 flex items-center justify-center p-2 shadow-xl group-hover:scale-110 transition-transform">
                      <img src={deal.image_url} alt={deal.title} className="w-full h-full object-contain" />
                    </div>
                    <h3 className="text-xl font-bold mb-3">{deal.title}</h3>
                    <p className="text-slate-400 text-sm mb-6 leading-relaxed line-clamp-2">{deal.description}</p>
                    <div className="flex items-baseline gap-3 mb-8">
                      <span className="text-3xl font-black text-white">${deal.new_price}</span>
                      <span className="text-slate-500 line-through text-sm font-bold">${deal.old_price}</span>
                    </div>
                    <div className="flex justify-between items-center bg-black/40 rounded-2xl p-4 border border-white/5">
                      <code className="text-yellow-400 font-mono font-bold">{deal.coupon_code}</code>
                      <button 
                        onClick={() => {
                          navigator.clipboard.writeText(deal.coupon_code);
                          alert('Coupon copied!');
                        }}
                        className="text-[10px] font-black uppercase tracking-widest bg-white text-slate-900 px-4 py-2 rounded-xl hover:bg-slate-200 transition-colors"
                      >
                        Copy
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};

export default HomePage;
