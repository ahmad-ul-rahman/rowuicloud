
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../utils/dataService';
import { BlogPost } from '../types';
import { format } from 'date-fns';
import { Calendar, Clock, Facebook, Twitter, Linkedin, Link as LinkIcon, MessageCircle, ArrowRight } from 'lucide-react';
import toast from 'react-hot-toast';
import { calculateReadTime } from '../utils/helpers';
import SEO from '../components/SEO';
import BlogCard from '../components/BlogCard';
import BlurImage from '../components/BlurImage';

const SinglePostPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [relatedPosts, setRelatedPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [readTime, setReadTime] = useState('5 min read');
  
  useEffect(() => {
    const fetchPost = async () => {
      if (!slug) return;
      setLoading(true);

      const result = await api.getPostBySlug(slug);
      
      if (result.post) {
        setPost(result.post);
        setReadTime(calculateReadTime(result.post.content));
        setRelatedPosts(result.related);
      }
      setLoading(false);
    };

    fetchPost();
    window.scrollTo(0, 0);
  }, [slug]);

  const handleShare = (platform: string) => {
    const url = window.location.href;
    const text = post?.title;
    let shareUrl = '';

    switch (platform) {
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text || '')}`;
        break;
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
        break;
      case 'linkedin':
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
        break;
      case 'whatsapp':
        shareUrl = `https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`;
        break;
      case 'copy':
        navigator.clipboard.writeText(url);
        toast.success('Link copied to clipboard!');
        return;
    }

    if (shareUrl) window.open(shareUrl, '_blank');
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div></div>;
  if (!post) return <div className="text-center py-20 text-slate-600 dark:text-slate-400">Post not found</div>;

  const authorName = post.authors?.name || post.author || 'Anonymous';
  const authorImg = post.authors?.profile_image || post.author_image || `https://ui-avatars.com/api/?name=${authorName}&background=random`;

  return (
    <article className="pb-20 bg-white dark:bg-slate-950">
      <SEO 
        title={post.title} 
        description={post.excerpt || post.content.substring(0, 160).replace(/<[^>]*>?/gm, '')}
        image={post.image_url}
        type="article"
        author={authorName}
        publishDate={post.created_at}
        category={post.category}
        slug={post.slug} // Ensure canonical URL uses the slug
      />

      {/* Header */}
      <div className="bg-slate-50 dark:bg-slate-900/30 py-16 md:py-20 border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Link to={`/${post.category.toLowerCase()}`} className="inline-block px-4 py-1.5 mb-6 text-xs font-bold tracking-widest text-primary-600 dark:text-primary-400 uppercase bg-primary-100 dark:bg-primary-900/20 rounded-full hover:bg-primary-200 dark:hover:bg-primary-900/40 transition-colors">
            {post.category}
          </Link>
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-extrabold text-slate-900 dark:text-white mb-8 leading-[1.2] tracking-tight">
            {post.title}
          </h1>
          
          <div className="flex flex-col md:flex-row items-center justify-center gap-6 md:gap-8 text-slate-500 dark:text-slate-400 text-sm font-medium">
            <div className="flex items-center gap-3">
              <BlurImage 
                src={authorImg} 
                alt={authorName} 
                noScale={true}
                loading="lazy"
                decoding="async"
                containerClassName="w-10 h-10 rounded-full border border-slate-200 dark:border-slate-700 shadow-sm"
                className="w-full h-full rounded-full object-cover"
              />
              <div className="text-left">
                <p className="font-bold text-slate-900 dark:text-white">{authorName}</p>
              </div>
            </div>
            <div className="hidden md:block w-1 h-1 rounded-full bg-slate-300 dark:bg-slate-700" />
            <div className="flex items-center gap-2">
              <Calendar size={16} className="text-primary-500" />
              <span>{format(new Date(post.created_at), 'MMMM d, yyyy')}</span>
            </div>
            <div className="hidden md:block w-1 h-1 rounded-full bg-slate-300 dark:bg-slate-700" />
            <div className="flex items-center gap-2">
              <Clock size={16} className="text-primary-500" />
              <span>{readTime}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Cover Image */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10 mb-16 relative z-10">
        <BlurImage 
          src={post.image_url} 
          alt={post.title} 
          loading="eager"
          decoding="async"
          containerClassName="w-full aspect-[16/9] shadow-2xl border-4 border-white dark:border-slate-800 rounded-3xl"
          className="w-full h-full object-cover rounded-3xl"
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col lg:flex-row gap-12">
        <div className="hidden lg:flex flex-col gap-4 sticky top-32 h-fit w-16 items-center">
          <button onClick={() => handleShare('copy')} title="Copy Link" className="p-3 rounded-full bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"><LinkIcon size={20} /></button>
          <button onClick={() => handleShare('twitter')} title="Share on X" className="p-3 rounded-full bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-sky-500 hover:bg-sky-50 dark:hover:bg-sky-900/20 transition-all"><Twitter size={20} /></button>
          <button onClick={() => handleShare('facebook')} title="Share on Facebook" className="p-3 rounded-full bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all"><Facebook size={20} /></button>
          <button onClick={() => handleShare('linkedin')} title="Share on LinkedIn" className="p-3 rounded-full bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-blue-700 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all"><Linkedin size={20} /></button>
          <button onClick={() => handleShare('whatsapp')} title="Share on WhatsApp" className="p-3 rounded-full bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-green-500 hover:bg-green-50 dark:hover:bg-green-900/20 transition-all"><MessageCircle size={20} /></button>
        </div>

        <div className="flex-1 max-w-3xl mx-auto">
           <div className="lg:hidden flex justify-center gap-4 mb-8">
              <button onClick={() => handleShare('copy')} className="p-2 rounded-full bg-slate-100 dark:bg-slate-800"><LinkIcon size={18} /></button>
              <button onClick={() => handleShare('whatsapp')} className="p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-green-600"><MessageCircle size={18} /></button>
              <button onClick={() => handleShare('twitter')} className="p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-sky-500"><Twitter size={18} /></button>
           </div>
          
           <div 
             className="prose prose-base md:prose-xl dark:prose-invert 
             prose-headings:font-bold prose-headings:text-slate-900 dark:prose-headings:text-white 
             prose-p:text-slate-600 dark:prose-p:text-slate-300 prose-p:text-[16px] md:prose-p:text-lg
             prose-a:text-primary-600 dark:prose-a:text-primary-400 
             prose-img:rounded-2xl 
             prose-blockquote:border-l-4 prose-blockquote:border-primary-500 prose-blockquote:bg-slate-50 dark:prose-blockquote:bg-slate-800/50 prose-blockquote:py-2 prose-blockquote:px-6 prose-blockquote:rounded-r-lg
             prose-ul:list-disc prose-ol:list-decimal
             max-w-none"
             dangerouslySetInnerHTML={{ __html: post.content }}
           />

           <div className="mt-16 pt-8 border-t border-slate-200 dark:border-slate-800">
             <div className="flex gap-2 flex-wrap">
               {['Design', 'UI', 'Tutorial', 'Tech', 'Row UI'].map(tag => (
                 <span key={tag} className="px-4 py-2 bg-slate-100 dark:bg-slate-800 rounded-full text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 transition-colors cursor-pointer">
                   #{tag}
                 </span>
               ))}
             </div>
           </div>
        </div>
        
        <div className="hidden lg:block w-16"></div>
      </div>

      {relatedPosts.length > 0 && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-20 pt-10 border-t border-slate-200 dark:border-slate-800">
          <div className="flex justify-between items-end mb-8">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Related Articles</h2>
            <Link to={`/${post.category.toLowerCase()}`} className="text-primary-600 dark:text-primary-400 font-semibold hover:underline flex items-center gap-1">
              See more <ArrowRight size={18} />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {relatedPosts.map(related => (
              <BlogCard key={related.id} post={related} />
            ))}
          </div>
        </div>
      )}
    </article>
  );
};

export default SinglePostPage;
