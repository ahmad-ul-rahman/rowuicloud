
import React, { useEffect, useRef } from 'react';
import { Link, LinkProps } from 'react-router-dom';
import { prefetchRoute } from '../utils/preloader';

// Fix: Use type alias instead of interface to allow Omit usage
type SmartLinkProps = Omit<LinkProps, 'prefetch'> & {
  prefetch?: 'hover' | 'viewport' | 'none';
};

const SmartLink: React.FC<SmartLinkProps> = ({ 
  prefetch = 'hover', 
  to, 
  children, 
  onMouseEnter,
  ...props 
}) => {
  const linkRef = useRef<HTMLAnchorElement>(null);
  const toPath = typeof to === 'string' ? to : to.pathname || '';

  const handleMouseEnter = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (prefetch === 'hover') {
      prefetchRoute(toPath);
    }
    if (onMouseEnter) onMouseEnter(e);
  };

  useEffect(() => {
    if (prefetch === 'viewport' && linkRef.current) {
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              prefetchRoute(toPath);
              observer.disconnect();
            }
          });
        },
        { rootMargin: '0px' }
      );
      
      observer.observe(linkRef.current);
      return () => observer.disconnect();
    }
  }, [prefetch, toPath]);

  return (
    <Link 
      ref={linkRef} 
      to={to} 
      onMouseEnter={handleMouseEnter} 
      {...props}
    >
      {children}
    </Link>
  );
};

export default SmartLink;
