
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Send } from 'lucide-react';
import { supabase } from '../supabaseClient';
import toast from 'react-hot-toast';

const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setLoading(true);
    try {
      const { error } = await supabase.from('subscribers').insert([
        { email, created_at: new Date().toISOString() }
      ]);
      if (error) throw error;
      toast.success('Welcome to Row UI!');
      setEmail('');
    } catch (error) {
      toast.error('Could not subscribe. Try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <footer className="bg-white dark:bg-slate-950 text-slate-600 dark:text-slate-400 pt-20 pb-10 border-t border-slate-200 dark:border-white/5 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Brand Column */}
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-2 group">
              <svg width="28" height="30" viewBox="0 0 458 500" fill="none" xmlns="http://www.w3.org/2000/svg" className="shrink-0">
                <path d="M449.465 100C428.873 41.7404 373.311 0 308 0H16C7.16345 0 0 7.16344 0 16V84C0 92.8366 7.16344 100 16 100H166.535H308C335.614 100 358 122.386 358 150C358 177.614 335.614 200 308 200H166.535H16C7.16346 200 0 207.163 0 216V284C0 292.837 7.16344 300 16 300H308C373.311 300 428.873 258.26 449.465 200C454.992 184.361 458 167.532 458 150C458 132.468 454.992 115.639 449.465 100ZM0 484C0 492.837 7.16344 500 16 500H166.535H426.84C437.882 500 445.548 489.055 440.337 479.319C415.072 432.113 365.286 400 308 400H16C7.16345 400 0 407.163 0 416V484Z" fill="#6647B6"/>
              </svg>
              <span className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white uppercase">Row UI</span>
            </Link>
            <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed max-w-xs">
              Premium resources for UI/UX designers and developers. RowUI helps you discover the latest trends, tools, and tech deals.
            </p>
          </div>

          {/* Categories Column */}
          <div className="space-y-6">
            <h3 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-[0.2em]">Categories</h3>
            <ul className="space-y-4">
              <li><Link to="/posts" className="hover:text-primary-600 dark:hover:text-white transition-colors text-sm">All Posts</Link></li>
              <li><Link to="/tech" className="hover:text-primary-600 dark:hover:text-white transition-colors text-sm">Tech & Development</Link></li>
              <li><Link to="/design" className="hover:text-primary-600 dark:hover:text-white transition-colors text-sm">UI/UX Design</Link></li>
              <li><Link to="/tools" className="hover:text-primary-600 dark:hover:text-white transition-colors text-sm">Design Tools</Link></li>
              <li><Link to="/guides" className="hover:text-primary-600 dark:hover:text-white transition-colors text-sm">Tutorials & Guides</Link></li>
            </ul>
          </div>

          {/* Company Column */}
          <div className="space-y-6">
            <h3 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-[0.2em]">Company</h3>
            <ul className="space-y-4">
              <li><Link to="/about" className="hover:text-primary-600 dark:hover:text-white transition-colors text-sm">About Us</Link></li>
              <li><Link to="/contact" className="hover:text-primary-600 dark:hover:text-white transition-colors text-sm">Contact</Link></li>
              <li><Link to="/privacy" className="hover:text-primary-600 dark:hover:text-white transition-colors text-sm">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-primary-600 dark:hover:text-white transition-colors text-sm">Terms & Conditions</Link></li>
            </ul>
          </div>

          {/* Stay Updated Column */}
          <div className="space-y-6">
            <h3 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-[0.2em]">Stay Updated</h3>
            <p className="text-sm leading-relaxed text-slate-500 dark:text-slate-400">
              Join the RowUI newsletter for the latest design resources and tech news.
            </p>
            <form onSubmit={handleSubscribe} className="relative group">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                required
                className="w-full bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 rounded-lg px-4 py-3 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-600 outline-none focus:ring-1 focus:ring-primary-500/50 transition-all"
              />
              <button 
                type="submit" 
                disabled={loading}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-primary-500 hover:text-primary-400 transition-colors disabled:opacity-50"
              >
                <Send size={18} />
              </button>
            </form>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-10 border-t border-slate-200 dark:border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-xs text-slate-400 dark:text-slate-500">
            © {new Date().getFullYear()} RowUI. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <Link to="/privacy" className="text-xs text-slate-400 dark:text-slate-500 hover:text-primary-600 dark:hover:text-white transition-colors">Privacy</Link>
            <Link to="/terms" className="text-xs text-slate-400 dark:text-slate-500 hover:text-primary-600 dark:hover:text-white transition-colors">Terms</Link>
            <Link to="/admin" className="text-xs text-slate-400 dark:text-slate-500 hover:text-primary-600 dark:hover:text-white transition-colors">Admin</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
