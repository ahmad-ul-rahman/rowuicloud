
import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

interface SEOProps {
  title: string;
  description: string;
  image?: string;
  type?: 'website' | 'article';
  author?: string;
  publishDate?: string;
  category?: string;
  slug?: string; // Explicitly for blog posts to ensure slug-based canonicals
}

const SEO: React.FC<SEOProps> = ({ 
  title, 
  description, 
  image = 'https://rowui.com/og-image.jpg', // Default OG Image
  type = 'website',
  author,
  publishDate,
  category,
  slug,
}) => {
  const location = useLocation();
  const siteName = 'Row UI';
  const baseUrl = 'https://rowui.com';

  useEffect(() => {
    // 1. Update Title
    document.title = `${title} | ${siteName}`;

    // 2. Determine Clean Path for Canonical
    // React Router's location.pathname provides the path without the hash prefix (in HashRouter) 
    // and without the query string.
    let cleanPath = location.pathname;

    // Force blog pages to use the slug-based path if a slug is provided
    if (type === 'article' && slug) {
      cleanPath = `/blog/${slug}`;
    }

    // Remove trailing slash if it exists (except for the root)
    if (cleanPath.length > 1 && cleanPath.endsWith('/')) {
      cleanPath = cleanPath.slice(0, -1);
    }

    const canonicalUrl = `${baseUrl}${cleanPath}`;

    // 3. Update Meta Tags
    const updateMeta = (name: string, content: string) => {
      let element = document.querySelector(`meta[name="${name}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute('name', name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const updateProperty = (property: string, content: string) => {
      let element = document.querySelector(`meta[property="${property}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute('property', property);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    // 4. Update/Create Canonical Tag (Strictly exactly one)
    const updateCanonical = (url: string) => {
      let element = document.querySelector(`link[rel="canonical"]`) as HTMLLinkElement;
      if (!element) {
        element = document.createElement('link');
        element.setAttribute('rel', 'canonical');
        document.head.appendChild(element);
      }
      element.setAttribute('href', url);
    };

    // Apply Standard Meta
    updateMeta('description', description);
    updateCanonical(canonicalUrl);

    // Apply Open Graph
    updateProperty('og:site_name', siteName);
    updateProperty('og:title', title);
    updateProperty('og:description', description);
    updateProperty('og:type', type);
    updateProperty('og:url', canonicalUrl);
    updateProperty('og:image', image);

    // Apply Twitter
    updateMeta('twitter:card', 'summary_large_image');
    updateMeta('twitter:title', title);
    updateMeta('twitter:description', description);
    updateMeta('twitter:image', image);

  }, [title, description, image, type, location.pathname, author, publishDate, category, slug]);

  return null;
};

export default SEO;
