
import React from 'react';
import { BlogPost } from '../types';
import { Calendar, Clock, ArrowUpRight } from 'lucide-react';
import { format } from 'date-fns';
import SmartLink from './SmartLink';
import { calculateReadTime } from '../utils/helpers';
import BlurImage from './BlurImage';

interface BlogCardProps {
  post: BlogPost;
  featured?: boolean;
}

const BlogCard: React.FC<BlogCardProps> = ({ post, featured = false }) => {
  const postLink = `/blog/${post.slug || post.id}`;
  const readTime = post.read_time || calculateReadTime(post.content);
  
  // Get author data from joined authors property
  const authorName = post.authors?.name || post.author || 'Anonymous';
  const authorImg = post.authors?.profile_image || post.author_image || `https://ui-avatars.com/api/?name=${authorName}&background=random`;

  if (featured) {
     return (
      <div className="cv-auto h-full">
        <SmartLink 
          to={postLink}
          prefetch="hover"
          className="group block h-full relative overflow-hidden rounded-3xl transform translate-z-0"
        >
          <div className="flex flex-col h-full bg-white dark:bg-slate-900 rounded-3xl transition-all duration-300">
            <div className="w-full h-full absolute inset-0">
              <BlurImage
                src={post.image_url || 'https://picsum.photos/800/600'}
                alt={post.title}
                loading="lazy"
                decoding="async"
                containerClassName="w-full h-full"
                className="object-cover w-full h-full transform transition-transform duration-700 ease-out group-hover:scale-105 opacity-40 dark:opacity-30"
              />
              <div className="absolute top-4 left-4 z-10">
                <span className="px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded-full backdrop-blur-md bg-white/20 text-white border border-white/20">
                  {post.category}
                </span>
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent pointer-events-none" />
            </div>

            <div className="flex flex-col flex-1 relative z-10 justify-end p-8 md:p-12 h-full">
              <div className="flex items-center gap-4 text-xs font-medium mb-3 text-slate-300">
                <div className="flex items-center gap-1.5">
                  <Calendar size={14} />
                  {post.created_at ? format(new Date(post.created_at), 'MMM d, yyyy') : 'Recent'}
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock size={14} />
                  {readTime}
                </div>
              </div>

              <h3 className="font-bold leading-tight mb-3 group-hover:text-primary-500 transition-colors text-3xl md:text-5xl text-white">
                {post.title}
              </h3>
              
              <p className="text-lg text-slate-200 mb-6 line-clamp-2 max-w-2xl">
                {post.excerpt || post.content.replace(/<[^>]*>?/gm, '').substring(0, 150) + '...'}
              </p>

              <div className="mt-auto flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <BlurImage 
                    src={authorImg} 
                    alt={authorName} 
                    noScale={true}
                    loading="lazy"
                    decoding="async"
                    containerClassName="rounded-full w-10 h-10 border-2 border-white/20 shadow-sm"
                    className="rounded-full object-cover w-full h-full"
                  />
                  <span className="text-sm font-semibold text-white">
                    {authorName}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </SmartLink>
      </div>
     );
  }

  return (
    <div className="cv-auto h-full">
      <SmartLink 
        to={postLink}
        prefetch="hover"
        className="group block h-full transform translate-z-0"
      >
        <div className="flex flex-col h-full bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-2xl hover:border-primary-500/30 transition-all duration-300 hover:-translate-y-1">
          
          <div className="relative aspect-[16/10] w-full overflow-hidden bg-slate-100 dark:bg-slate-800">
            <BlurImage
              src={post.image_url || 'https://picsum.photos/800/600'}
              alt={post.title}
              loading="lazy"
              decoding="async"
              containerClassName="w-full h-full"
              className="object-cover w-full h-full transform transition-transform duration-500 ease-out group-hover:scale-105"
            />
            
            <div className="absolute top-4 left-4 z-10">
              <span className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider rounded-full backdrop-blur-md bg-white/90 dark:bg-slate-900/90 text-slate-900 dark:text-white shadow-sm border border-slate-200 dark:border-slate-700">
                {post.category}
              </span>
            </div>
          </div>

          <div className="flex flex-col flex-1 p-6">
            <div className="flex items-center gap-4 text-xs font-semibold text-slate-400 dark:text-slate-500 mb-4">
              <div className="flex items-center gap-1.5">
                <Calendar size={14} className="text-primary-500" />
                {post.created_at ? format(new Date(post.created_at), 'MMM d, yyyy') : 'Recent'}
              </div>
              <div className="w-1 h-1 rounded-full bg-slate-300 dark:bg-slate-700"></div>
              <div className="flex items-center gap-1.5">
                <Clock size={14} />
                {readTime}
              </div>
            </div>

            <h3 className="text-xl font-bold leading-tight text-slate-900 dark:text-white mb-3 group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors line-clamp-2">
              {post.title}
            </h3>
            
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-6 line-clamp-2 flex-1 leading-relaxed">
              {post.excerpt || post.content.replace(/<[^>]*>?/gm, '').substring(0, 120) + '...'}
            </p>

            <div className="mt-auto pt-5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <BlurImage 
                  src={authorImg} 
                  alt={authorName} 
                  noScale={true}
                  loading="lazy"
                  decoding="async"
                  containerClassName="w-8 h-8 rounded-full border border-slate-100 dark:border-slate-800 shadow-sm"
                  className="w-full h-full rounded-full object-cover"
                />
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  {authorName}
                </span>
              </div>
              
              <span className="flex items-center justify-center w-8 h-8 rounded-full bg-slate-50 dark:bg-slate-800 text-slate-400 dark:text-slate-500 group-hover:bg-primary-600 group-hover:text-white transition-all duration-300">
                <ArrowUpRight size={16} />
              </span>
            </div>
          </div>
        </div>
      </SmartLink>
    </div>
  );
};

export default BlogCard;
