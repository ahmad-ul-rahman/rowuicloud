
import React, { useState } from 'react';

interface BlurImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  className?: string;
  containerClassName?: string;
  noScale?: boolean;
}

const BlurImage: React.FC<BlurImageProps> = ({ 
  src, 
  alt, 
  className = "", 
  containerClassName = "",
  noScale = false,
  ...props 
}) => {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <div className={`relative overflow-hidden bg-slate-200 dark:bg-slate-800 ${containerClassName}`}>
      {/* Background Decoy - Solid color skeleton for stability */}
      {!isLoaded && (
        <div className="absolute inset-0 bg-slate-200 dark:bg-slate-800 transition-opacity duration-300" />
      )}
      
      <img
        src={src}
        alt={alt}
        onLoad={() => setIsLoaded(true)}
        loading={props.loading || "lazy"}
        decoding="async"
        className={`
          block w-full h-full object-cover
          ${isLoaded ? 'opacity-100' : 'opacity-0'}
          ${className}
        `}
        style={{ 
          backfaceVisibility: 'hidden', 
          transform: 'translateZ(0)',
          transition: 'opacity 0.2s ease-out' // Fast opacity fade only, no scale or blur
        }}
        {...props}
      />
    </div>
  );
};

export default BlurImage;
