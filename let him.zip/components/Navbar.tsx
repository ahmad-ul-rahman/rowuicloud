
import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Menu, X, Sun, Moon } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SmartLink from './SmartLink';

interface NavbarProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ darkMode, toggleTheme }) => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Tech', path: '/tech' },
    { name: 'Design', path: '/design' },
    { name: 'Tools', path: '/tools' },
    { name: 'Guides', path: '/guides' },
  ];

  return (
    <nav className="fixed w-full z-50 top-0 left-0">
      <div className="glass-panel border-b border-slate-200/50 dark:border-white/5 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20 md:h-24">
            
            {/* Brand Logo */}
            <div className="flex-shrink-0 flex items-center z-20">
              <SmartLink to="/" prefetch="hover" className="group flex items-center gap-2.5">
                <svg width="32" height="35" viewBox="0 0 458 500" fill="none" xmlns="http://www.w3.org/2000/svg" className="shrink-0">
                  <path d="M449.465 100C428.873 41.7404 373.311 0 308 0H16C7.16345 0 0 7.16344 0 16V84C0 92.8366 7.16344 100 16 100H166.535H308C335.614 100 358 122.386 358 150C358 177.614 335.614 200 308 200H166.535H16C7.16346 200 0 207.163 0 216V284C0 292.837 7.16344 300 16 300H308C373.311 300 428.873 258.26 449.465 200C454.992 184.361 458 167.532 458 150C458 132.468 454.992 115.639 449.465 100ZM0 484C0 492.837 7.16344 500 16 500H166.535H426.84C437.882 500 445.548 489.055 440.337 479.319C415.072 432.113 365.286 400 308 400H16C7.16345 400 0 407.163 0 416V484Z" fill="#6647B6"/>
                </svg>
                <span className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white uppercase">Row UI</span>
              </SmartLink>
            </div>

            {/* Main Navigation */}
            <div className="hidden md:flex flex-1 justify-center">
              <div className="flex items-center space-x-1 lg:space-x-2">
                {navLinks.map((link) => {
                  const isActive = location.pathname === link.path;
                  return (
                    <SmartLink
                      key={link.name}
                      to={link.path}
                      prefetch="viewport"
                      className={`relative px-4 py-2.5 rounded-2xl text-sm font-bold tracking-tight transition-all ${
                        isActive
                          ? 'text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/20'
                          : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      {link.name}
                      {isActive && (
                        <motion.div 
                          layoutId="navDot"
                          className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary-500"
                        />
                      )}
                    </SmartLink>
                  );
                })}
              </div>
            </div>

            {/* Actions Area */}
            <div className="flex items-center gap-3 z-20">
              <div className="hidden md:flex items-center gap-3">
                <button
                  onClick={toggleTheme}
                  className="p-3 rounded-2xl text-slate-500 hover:text-primary-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  aria-label="Toggle Theme"
                >
                  {darkMode ? <Sun size={22} /> : <Moon size={22} />}
                </button>
                <div className="h-8 w-px bg-slate-200 dark:bg-slate-800 mx-2" />
                <SmartLink to="/contact" prefetch="hover">
                  <button className="bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-6 py-3 rounded-2xl text-sm font-black shadow-lg shadow-slate-900/20 dark:shadow-white/10 hover:scale-105 active:scale-95 transition-all">
                    Contact
                  </button>
                </SmartLink>
              </div>

              {/* Mobile Interaction */}
              <div className="md:hidden flex items-center gap-2">
                 <button onClick={toggleTheme} className="p-2 text-slate-500 hover:text-primary-500 transition-colors">
                   {darkMode ? <Sun size={22} /> : <Moon size={22} />}
                 </button>
                 <button 
                  onClick={() => setIsOpen(!isOpen)} 
                  className={`p-2 rounded-xl transition-all ${isOpen ? 'bg-slate-100 dark:bg-slate-800 text-primary-500' : 'text-slate-900 dark:text-white'}`}
                >
                   {isOpen ? <X size={24} /> : <Menu size={24} />}
                 </button>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Flyout */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="md:hidden fixed inset-x-0 bg-white/98 dark:bg-slate-950/98 backdrop-blur-3xl border-b border-slate-200 dark:border-slate-800 shadow-3xl px-6 py-10 space-y-6"
            >
                <div className="grid grid-cols-2 gap-4">
                  {navLinks.map((link) => (
                    <SmartLink
                      key={link.name}
                      to={link.path}
                      onClick={() => setIsOpen(false)}
                      className="flex items-center justify-center p-5 rounded-[24px] bg-slate-50 dark:bg-slate-900 text-sm font-black text-slate-600 dark:text-slate-300 hover:bg-primary-50 dark:hover:bg-primary-900/20 hover:text-primary-600 transition-all border border-transparent hover:border-primary-100 dark:hover:border-primary-800"
                    >
                      {link.name}
                    </SmartLink>
                  ))}
                </div>
                
                <SmartLink to="/contact" onClick={() => setIsOpen(false)} className="block w-full text-center bg-primary-600 text-white py-5 rounded-[24px] font-black shadow-2xl shadow-primary-500/20 active:scale-95 transition-all">
                  Get in Touch
                </SmartLink>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  );
};

export default Navbar;
